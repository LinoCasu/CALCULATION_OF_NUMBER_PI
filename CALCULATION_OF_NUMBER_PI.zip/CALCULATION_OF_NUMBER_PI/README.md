"# CALCULATION_OF_NUMBER_PI AFTER THE FORMULA OF CHUDNOVSKI
- 6GB RAM USED - 64GB RAM NEEDED !!!
- CALCULATION OF 32.000.000.000 DIGITS OF PI
- USE AT YOUR OWN RISK !!!
- CAN WRITE RAM FULL AND BREAK SYSTEM 
- USE AT OWN RISK !!!
- CAN BREAK WORLD RECORD !!!
- WINDOES MENU
- Run
- 1. start.bat
- ![run-command](https://github.com/user-attachments/assets/5abec9d0-f8a1-4a5a-82ed-c7b5624d55d9)
- LINUX MENU
- Run
- chmod a+x *.sh
- ./start.sh
- If Python Dependencies are not installed yet -> start before:
- chmod a+x *.sh
- ./pi-install.sh
- ![linux-menu](https://github.com/user-attachments/assets/9eb0f32e-5f25-4315-a2d6-c44e89806579)




---
COMMAND:
- tpi -T 8 -m 6Gi -d 32G -o pi.txt 32G
- MAX TESTED - NEED 64 GB OF RAM !!!
- IF YOU HAVE LESS RAM CHANGE TO:
- tpi -T 8 -m 4Gi -d 10G -o pi.txt 10G
- AND CALCULATE ONLY 10.000.000.000 DIGITS
- 4Gi -> 4GB of primary RAM used -> 32GB RAM NEEDED !!!
- 2Gi -> 2GB of primary RAM used -> 16GB RAM NEEDED !!!
- -d -> DIGITS -> -d 100G -> 100.000.000.000 DIGITS
---
ENJOY AT OWN RISK !!!
