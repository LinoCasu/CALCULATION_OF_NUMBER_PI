#!/bin/bash

# Start the pi.py script using the active Python environment
echo "Starting Python script pi.py..."
python pi.py
